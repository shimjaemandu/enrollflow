# EnrollFlow 2.3 — 실제 배포 체크리스트

## A. Supabase
1. 새 프로젝트 생성
2. SQL Editor에서 아래 순서로 실행
   - `supabase/migrations/001_enrollflow.sql`
   - `supabase/migrations/002_ai_conversion.sql`
   - `supabase/migrations/003_production_hardening.sql`
   - `supabase/migrations/004_revenue_recovery.sql`
3. Connect/API Keys에서 `Project URL`, `Publishable key`, `Secret key` 확인
4. Auth 이메일 로그인 사용 시 Site URL과 Redirect URL을 실제 EnrollFlow 도메인으로 설정

## B. 운영 비밀값 생성
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```
서로 다른 값을 `SESSION_SECRET`, `ADMIN_TOKEN`, `CRON_SECRET`에 사용하세요. `BILLING_ENCRYPTION_KEY`는 정확히 32바이트 키(위 명령의 64자리 hex)를 사용합니다.

## C. OpenAI
서버 환경변수에 `OPENAI_API_KEY`만 저장합니다. 브라우저 코드에는 넣지 않습니다. API 실패/한도 초과 시 규칙 엔진으로 폴백합니다.

## D. Toss Payments
테스트 키부터 연결합니다. 자동결제는 계약/심사가 완료된 운영 주체만 라이브 키로 전환하세요. EnrollFlow는 카드번호를 직접 저장하지 않고 Toss billingKey만 사용하며, billingKey 자체도 AES-256-GCM으로 암호화해 DB에 저장합니다.

## E. Render
GitHub 저장소 루트에 이 프로젝트를 올리고 Render Blueprint에서 `render.yaml`을 선택합니다. 아래 값을 Secret/Environment Variable로 채웁니다.
- `APP_URL`
- `SESSION_SECRET`
- `ADMIN_TOKEN`
- `CRON_SECRET`
- `BILLING_ENCRYPTION_KEY`
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SECRET_KEY`
- `TOSS_CLIENT_KEY` / `TOSS_SECRET_KEY` (테스트부터)
- `OPENAI_API_KEY` (선택)

배포 뒤 `/api/ready`가 HTTP 200인지 확인하세요. 이 endpoint는 production에서 Supabase DB까지 실제 조회합니다.

## F. v2.3 데이터 확인
첫 테스트 문의를 넣은 뒤 아래를 확인하세요.
- 유입경로가 저장되는지
- 단계가 `문의 → 전화상담 → 방문상담 → 레벨테스트 → 체험수업 → 등록` 순서로 바뀌는지
- 월 수강료를 입력한 등록 고객이 유입경로별 등록매출에 반영되는지
- 이탈 고객의 이탈 사유와 최고 도달 단계가 유지되는지
- 후속 연락이 지난 우선순위 높은 고객이 회수 후보로 나타나는지

## G. 출시 전 필수
실제 상호/대표자/사업자 정보, 환불·해지 정책, 개인정보 보유기간, 처리위탁/국외이전 안내, 고객지원 연락처를 확정해야 합니다. 결제사나 사업자 서비스의 연령·본인확인·사업자 요건은 우회하지 말고 적격 운영 주체로 진행해야 합니다.
