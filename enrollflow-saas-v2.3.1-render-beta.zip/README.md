# EnrollFlow 2.3

학원별 상담 링크 → 문의 수집 → 전환 파이프라인 → 구독 결제를 하나의 흐름으로 만든 B2B SaaS 프로젝트입니다.

## 2.3 핵심 기능

### 신규등록 매출 분석·복구

- 유입경로: 네이버 검색/광고, 네이버 블로그, 인스타그램, 카카오, 지인추천, 방문, 홈페이지, 기타
- 학원 전용 6단계 퍼널: 문의 → 전화상담 → 방문상담 → 레벨테스트 → 체험수업 → 등록
- 이탈해도 `highest_stage_rank`에 최고 도달 단계가 남아 퍼널이 왜곡되지 않음
- 고객별 월 수강료 입력 후 유입경로별 실제 등록 월액 합계 계산
- 가격/시간표/거리/경쟁학원/레벨 불일치/연락두절/등록연기 이탈 사유 분석
- 후속 연락 시점이 지났고 우선순위 60점 이상인 고객을 회수 후보로 표시
- `회수 후보 월매출`은 예측값이 아니라 회수 후보 고객에게 입력된 월 수강료의 합계


- 이메일/비밀번호 회원가입·로그인
- 가입 시 학원(tenant) 자동 생성
- 학원별 전용 상담 링크 (`/apply?academy=...`)
- 다른 학원 데이터가 섞이지 않는 tenant 분리
- Supabase Auth + PostgreSQL + RLS 전환 구조
- 상담폼 개인정보 동의 기록
- Starter / Business / Scale 구독 상태
- Toss Payments v2 자동결제 카드 등록 흐름
- 서버 전용 빌링키 저장
- 월 결제 스케줄러용 보호된 cron endpoint
- 결제 재시도 idempotency 설계
- 운영자 MRR 대시보드
- production fail-fast 설정
- 자동 smoke test
- 상담 즉시 기본 우선순위 분석(외부 AI 장애와 무관하게 동작)
- OpenAI 선택형 정밀 분석
- 우선순위 점수 + 근거 + 이탈 위험 + 추천 대응
- 오늘 연락할 상담자 자동 큐
- 추천 연락 문구 생성/복사

## 1. 로컬에서 바로 실행

Node.js 20 이상이면 외부 npm 패키지 없이 실행됩니다.

```bash
npm start
```

브라우저에서:

- 랜딩: `http://localhost:3000`
- 회원가입: `http://localhost:3000/signup`
- 로그인: `http://localhost:3000/login`
- 학원 대시보드: `http://localhost:3000/dashboard`
- 운영자: `http://localhost:3000/admin`

Supabase 키가 없으면 **로컬 개발 fallback DB**를 사용합니다. 비밀번호는 scrypt 해시로만 저장됩니다. 이 fallback은 로컬 테스트용이며 production에서는 서버가 아예 시작되지 않도록 막았습니다.

## 2. 자동 테스트

```bash
npm run check
npm test
```

테스트 항목에는 회원가입, 로그인 세션, 학원 자동 생성, 공개 상담 접수, 학원별 데이터 격리, 파이프라인 변경, 지표, 결제 미설정 안전 처리, CSRF성 cross-origin 차단, 운영자 인증, 로그아웃, 잘못된 JSON 처리가 포함됩니다.

## 3. Supabase 연결

1. Supabase 프로젝트를 만듭니다.
2. SQL Editor에서 `001_enrollflow.sql` → `002_ai_conversion.sql` → `003_production_hardening.sql` → `004_revenue_recovery.sql` 순서로 실행합니다.
3. `.env.example`을 `.env`로 복사합니다.
4. 아래 3개 값을 채웁니다.

```env
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
SUPABASE_SECRET_KEY=sb_secret_...
BILLING_ENCRYPTION_KEY=<32-byte secret>
```

`SUPABASE_SECRET_KEY`는 절대 브라우저/공개 GitHub에 넣으면 안 됩니다. 서버 전용입니다. 2.3은 publishable/secret 키 이름을 우선 사용하며 legacy anon/service_role 이름도 임시 호환합니다.

### 이메일 인증

Supabase에서 이메일 확인을 켠 경우 가입 직후 화면에 이메일 인증 안내가 나오고, 인증 후 로그인합니다. Auth의 Site URL/Redirect URL은 실제 서비스 도메인에 맞춰 설정하세요.


## 3-1. AI 상담 분석

AI 키가 없어도 서비스는 멈추지 않습니다. 모든 신규 문의는 즉시 내장 규칙 엔진으로 우선순위 점수, 긍정 신호, 확인할 점, 추천 대응, 추천 연락 문구를 생성합니다.

실제 OpenAI 모델 분석을 사용하려면 `.env`에 아래 값을 추가합니다.

```env
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5.6-luna
```

대시보드의 `AI 재분석` 버튼을 누르면 서버가 OpenAI Responses API를 호출합니다. API 키는 브라우저에 노출되지 않습니다. OpenAI 호출이 실패하거나 시간 초과가 나면 내장 분석 결과로 자동 폴백합니다. AI는 **등록확률을 출력하지 않고 상담 우선순위 점수(10~100)**만 제공합니다. 점수는 먼저 연락할 순서를 돕는 운영 참고값이며 실제 등록을 예측하거나 보장하지 않습니다.

### 후속 연락 규칙

- 신규 문의: 즉시 오늘 연락 대상으로 표시
- 전화상담 단계: 마지막 갱신 48시간 후 후속 연락
- 방문상담·레벨테스트·체험수업 단계: 마지막 갱신 24시간 후 후속 연락
- 등록/이탈: 후속 연락 큐에서 제외

`연락 완료` 또는 `후속 완료`를 누르면 다음 후속 시점이 자동으로 다시 계산됩니다.

## 4. Toss Payments 자동결제

`.env`에 자동결제로 계약된 테스트 또는 라이브 키를 넣습니다.

```env
TOSS_CLIENT_KEY=test_ck_...
TOSS_SECRET_KEY=test_sk_...
```

흐름:

1. 로그인 사용자가 요금제 선택
2. 브라우저에서 Toss SDK v2 `requestBillingAuth()` 호출
3. 성공 redirect에서 `authKey`, `customerKey` 수신
4. 서버가 `/v1/billing/authorizations/issue` 호출
5. `billingKey`를 서버 전용 DB 테이블에 저장
6. 무료체험 종료 시 cron이 `/v1/billing/{billingKey}` 호출
7. 성공하면 다음 결제일을 1개월 뒤로 이동

카드 거절처럼 Toss가 명확한 오류 코드를 반환한 경우 다음 날 재시도합니다. 네트워크 타임아웃처럼 결과가 애매한 경우 동일 주문/idempotency key로 다시 확인해 중복 과금 위험을 줄입니다.

**중요:** 토스 자동결제는 추가 계약/리스크 검토가 필요한 기능입니다. 실제 라이브 결제는 서비스 운영 주체가 토스페이먼츠의 계약·사업자·본인확인 요건을 충족한 뒤 활성화해야 합니다. 연령/사업자 요건을 우회하도록 설계되어 있지 않습니다.

## 5. 정기결제 cron

보호 endpoint:

```text
GET /api/cron/billing
Authorization: Bearer <CRON_SECRET>
```

직접 실행:

```bash
APP_URL=https://your-domain.example CRON_SECRET=... npm run billing:cron
```

`render.yaml`에는 매시간 due 결제를 확인하는 Render Cron Job도 정의돼 있습니다. 실제 결제는 `next_billing_at`이 지난 고객만 처리합니다.

## 6. Render 배포

프로젝트를 GitHub 저장소에 올린 뒤 Render Blueprint에서 `render.yaml`을 사용하면 web service + billing cron을 만들 수 있습니다.

필수 production 환경변수:

```env
NODE_ENV=production
APP_URL=https://YOUR_DOMAIN
SESSION_SECRET=<32자 이상 강한 랜덤값>
ADMIN_TOKEN=<강한 랜덤값>
CRON_SECRET=<강한 랜덤값>
SUPABASE_URL=...
SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
SUPABASE_SECRET_KEY=sb_secret_...
BILLING_ENCRYPTION_KEY=<32-byte secret>
TOSS_CLIENT_KEY=...
TOSS_SECRET_KEY=...
```

production에서는 Supabase 미설정, 약한 세션 비밀키, HTTP APP_URL 등 위험한 설정이면 fail-fast로 서버 시작을 거부합니다.

배포 전 환경변수 검증:

```bash
npm run preflight
```

## 7. 보안 구조

- HttpOnly + SameSite 세션 쿠키
- production Secure cookie
- Supabase access token/refresh token 브라우저 JS 비노출
- 서비스 역할 키 및 Toss secret server-only
- RLS + SQL grants로 tenant 경계 추가
- billing table은 `authenticated`/`anon` 권한 없음
- Origin / Sec-Fetch-Site 기반 상태 변경 요청 방어
- CSP, frame 제한, MIME sniffing 방지
- 입력 길이/형식 검증
- honeypot + IP rate limit
- 운영자 토큰 timing-safe 검증
- 결제 idempotency key
- Toss billingKey AES-256-GCM 암호화 저장
- 요금제별 일일 OpenAI 분석 한도(Starter 30 / Business 150 / Scale 500)
- `/api/ready`에서 production DB 연결 확인

## 8. 월 1,000만 원 목표 구조

현재 정가 기준:

- Starter: 99,000원/월
- Business: 199,000원/월
- Scale: 299,000원/월

예를 들어 Business 51곳이면 표시상 MRR은 10,149,000원입니다. 이는 **매출 목표 모델**일 뿐 실제 매출/순이익을 보장하지 않습니다. 결제 수수료, 세금, 고객 획득비용, 환불, 해지, 서버비 등을 별도로 계산해야 합니다.

## 9. 실제 출시 전에 아직 운영자가 채워야 하는 것

코드 오류와 별개로 아래 항목은 개발자가 임의로 확정할 수 없습니다.

- 실제 상호/대표자/사업자 정보
- 고객지원 이메일·전화번호
- 개인정보 보유기간 및 삭제 절차
- 개인정보 처리 위탁/국외이전 고지
- 환불/해지 정책
- 토스페이먼츠 라이브 자동결제 계약
- 실제 도메인
- Supabase 이메일 발신/인증 설정

`/privacy`, `/terms` 페이지는 이 때문에 **초안**으로 명확히 표시돼 있습니다. 실제 출시 전에 운영 주체에 맞게 확정하세요.


## 10. 운영 하드닝

- Supabase의 새 publishable/secret API key 체계 우선 지원
- Render readiness check가 Supabase 연결까지 확인
- billingKey를 애플리케이션 레벨 AES-256-GCM으로 암호화
- OpenAI 호출을 요금제별 일일 quota로 제한해 비용 폭주 방지
- AI는 낮은 reasoning effort + 최대 출력 토큰 제한을 사용하고 실패 시 rules fallback
- SIGTERM/SIGINT graceful shutdown
- 자세한 배포 순서는 `DEPLOYMENT.md` 참고
