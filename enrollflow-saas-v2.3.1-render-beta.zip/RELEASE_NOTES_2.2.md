# EnrollFlow 2.2 release notes

- Supabase 2026 publishable/secret API key support with legacy aliases
- Correct separation of `apikey` and authenticated user JWT headers
- AES-256-GCM encryption for stored Toss billing keys
- Atomic per-tenant daily OpenAI quotas in Supabase
- Starter 30 / Business 150 / Scale 500 AI analyses per day
- OpenAI Responses API output-token cap and low reasoning effort
- `/api/ready` database-readiness endpoint for Render
- Render Blueprint updated to current plan IDs and readiness health check
- Graceful SIGTERM/SIGINT shutdown
- GitHub Actions syntax + smoke-test CI
- 003 production-hardening migration and deployment checklist
