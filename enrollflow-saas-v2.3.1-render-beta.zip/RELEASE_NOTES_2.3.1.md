# EnrollFlow 2.3.1 — Render Beta Deploy

- Render beta web service defaults to the free plan.
- Billing cron is intentionally omitted until live billing is enabled.
- APP_URL automatically uses Render's RENDER_EXTERNAL_URL when APP_URL is not set.
- Render-generated BILLING_ENCRYPTION_KEY values are accepted by deriving a stable AES-256 key with SHA-256 when the generated secret is 32+ characters.
- Supabase project URL and publishable key are prefilled; only SUPABASE_SECRET_KEY remains a required Supabase secret for production startup.
- Toss/OpenAI remain optional for first public beta deployment.
