const customers = document.querySelector('#customers');
const out = document.querySelector('#customerOut');
const mrr = document.querySelector('#mrr');
function renderMrr(){ const n=Number(customers?.value||0); if(out) out.textContent=`${n}곳`; if(mrr) mrr.textContent=new Intl.NumberFormat('ko-KR',{style:'currency',currency:'KRW',maximumFractionDigits:0}).format(n*199000); }
customers?.addEventListener('input',renderMrr); renderMrr();
