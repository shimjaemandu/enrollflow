import crypto from 'node:crypto';
const publishable=process.env.SUPABASE_PUBLISHABLE_KEY||process.env.SUPABASE_ANON_KEY;
const secret=process.env.SUPABASE_SECRET_KEY||process.env.SUPABASE_SERVICE_ROLE_KEY;
const required=['APP_URL','SESSION_SECRET','ADMIN_TOKEN','CRON_SECRET','SUPABASE_URL'];
const missing=required.filter(k=>!process.env[k]);
if(!publishable) missing.push('SUPABASE_PUBLISHABLE_KEY');
if(!secret) missing.push('SUPABASE_SECRET_KEY');
const warnings=[];
function validAes(raw){if(!raw)return false;if(/^[0-9a-f]{64}$/i.test(raw))return true;try{return Buffer.from(raw.replace(/-/g,'+').replace(/_/g,'/'),'base64').length===32;}catch{return false;}}
if(!validAes(process.env.BILLING_ENCRYPTION_KEY||'')) missing.push('BILLING_ENCRYPTION_KEY(32-byte)');
if(!process.env.TOSS_CLIENT_KEY||!process.env.TOSS_SECRET_KEY) warnings.push('Toss Payments keys are missing: live billing stays disabled.');
if(!process.env.OPENAI_API_KEY) warnings.push('OPENAI_API_KEY is missing: rule-based analysis stays active.');
if(process.env.APP_URL&&!process.env.APP_URL.startsWith('https://')) warnings.push('APP_URL must use HTTPS in production.');
if(process.env.SESSION_SECRET&&process.env.SESSION_SECRET.length<32) warnings.push('SESSION_SECRET should be at least 32 characters.');
if(missing.length){console.error(`Missing/invalid production env vars: ${[...new Set(missing)].join(', ')}`);process.exit(1);}
for(const w of warnings)console.warn(`WARNING: ${w}`);
console.log('Production preflight passed.');
