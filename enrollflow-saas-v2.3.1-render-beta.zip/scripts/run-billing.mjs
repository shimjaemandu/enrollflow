const app=(process.env.APP_URL||'').replace(/\/$/,'');
const secret=process.env.CRON_SECRET||'';
if(!app||!secret){console.error('APP_URL and CRON_SECRET are required.');process.exit(1);}
const r=await fetch(`${app}/api/cron/billing`,{headers:{Authorization:`Bearer ${secret}`},signal:AbortSignal.timeout(180_000)});
const text=await r.text();
if(!r.ok){console.error(`Billing cron failed (${r.status}): ${text}`);process.exit(1);}
console.log(text);
