import { server } from '../server.mjs';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const root=fileURLToPath(new URL('..',import.meta.url));
const storeFile=join(root,'data','store.json');
const original=await readFile(storeFile,'utf8').catch(()=>'{}');
const blank=JSON.stringify({users:[],organizations:[],memberships:[],leads:[],billingProfiles:[],payments:[],events:[]},null,2);
await writeFile(storeFile,blank);
let failures=0;
const assert=(ok,label)=>{console.log(`${ok?'✓':'✗'} ${label}`);if(!ok)failures++;};
function cookieFrom(r){const raw=r.headers.get('set-cookie')||'';return raw.split(',').map(s=>s.trim().split(';')[0]).filter(Boolean).join('; ');}
async function json(r){return await r.json();}
async function patch(base,cookie,id,body){const r=await fetch(`${base}/api/tenant/leads/${id}`,{method:'PATCH',headers:{cookie,'content-type':'application/json'},body:JSON.stringify(body)});return [r,await json(r)];}
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const base=`http://127.0.0.1:${server.address().port}`;
try{
  let r=await fetch(`${base}/api/health`);let j=await json(r);assert(r.status===200&&j.ok&&j.version==='2.3.0'&&typeof j.aiEnabled==='boolean','health/version + AI status');
  r=await fetch(`${base}/api/ready`);j=await json(r);assert(r.status===200&&j.ok,'readiness endpoint');
  r=await fetch(`${base}/dashboard`);const dashboardHtml=await r.text();assert(r.status===200&&dashboardHtml.includes('유입경로별 등록매출')&&dashboardHtml.includes('학원 전용 등록 퍼널')&&dashboardHtml.includes('회수 후보 월매출'),'2.3 revenue dashboard page');

  const u1=`owner1-${Date.now()}@example.com`;
  r=await fetch(`${base}/api/auth/signup`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({academyName:'알파수학학원',contactName:'김원장',email:u1,password:'StrongPass1234',agree:'on'})});j=await json(r);const c1=cookieFrom(r);assert(r.status===201&&j.ok&&c1.includes('ef_access='),'signup creates authenticated tenant');
  r=await fetch(`${base}/api/me`,{headers:{cookie:c1}});j=await json(r);const org1=j.organization;assert(r.status===200&&org1?.slug&&org1.name==='알파수학학원','me returns organization');

  r=await fetch(`${base}/api/public/leads`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({slug:org1.slug,name:'학생보호자',phone:'010-1234-5678',email:'parent@example.com',grade:'중3',goal:'exam',timing:'now',sourceChannel:'naver_blog',sourceDetail:'중3 내신 글',message:'중간고사 대비 수학 상담을 받고 싶고 가능한 빨리 수업을 시작하고 싶습니다.',privacyConsent:'on'})});j=await json(r);const leadId=j.leadId;assert(r.status===201&&j.ok&&leadId,'public lead creation with source attribution');

  r=await fetch(`${base}/api/tenant/leads`,{headers:{cookie:c1}});j=await json(r);let first=j.leads[0];assert(r.status===200&&j.leads.length===1&&first.id===leadId&&first.analysis?.priorityScore>=10&&first.analysis?.priorityScore<=100&&first.analysis?.probability===undefined,'lead uses priority score, not probability');
  assert(first.sourceChannel==='naver_blog'&&first.sourceDetail==='중3 내신 글'&&first.highestStageRank===0,'source + initial funnel rank stored');

  [r,j]=await patch(base,c1,leadId,{monthlyFee:350000});assert(r.status===200&&j.lead.monthlyFee===350000,'monthly tuition can be assigned');
  r=await fetch(`${base}/api/tenant/followups`,{headers:{cookie:c1}});j=await json(r);assert(r.status===200&&j.dueCount===1&&j.followups[0].id===leadId,'new lead enters recovery follow-up queue');
  r=await fetch(`${base}/api/tenant/metrics`,{headers:{cookie:c1}});j=await json(r);assert(r.status===200&&j.metrics.recovery.candidateCount===1&&j.metrics.recovery.candidateMonthlyRevenue===350000,'recovery candidate revenue metric');
  assert(j.metrics.funnel.inquiry===1&&j.metrics.funnel.phone===0&&j.metrics.avgPriorityScore>0,'six-stage funnel begins at inquiry');

  r=await fetch(`${base}/api/tenant/leads/${leadId}/analyze`,{method:'POST',headers:{cookie:c1}});j=await json(r);assert(r.status===200&&j.analysis?.priorityScore>=10&&j.analysis?.probability===undefined&&typeof j.aiEnabled==='boolean','AI analysis uses safe priority score');

  for (const [stage,rank,key] of [['phone',1,'phone'],['visit',2,'visit'],['level_test',3,'levelTest'],['trial',4,'trial']]){
    [r,j]=await patch(base,c1,leadId,{stage});assert(r.status===200&&j.lead.stage===stage&&j.lead.highestStageRank===rank,`${stage} updates current/highest stage`);
    r=await fetch(`${base}/api/tenant/metrics`,{headers:{cookie:c1}});j=await json(r);assert(j.metrics.funnel[key]===1,`${key} cumulative funnel count`);
  }
  [r,j]=await patch(base,c1,leadId,{stage:'won'});assert(r.status===200&&j.lead.stage==='won'&&j.lead.highestStageRank===5,'won pipeline update');
  r=await fetch(`${base}/api/tenant/metrics`,{headers:{cookie:c1}});j=await json(r);assert(j.metrics.won===1&&j.metrics.registeredMonthlyRevenue===350000&&j.metrics.funnel.won===1,'registered monthly revenue + funnel');
  const naver=j.metrics.sourcePerformance.find(x=>x.source==='naver_blog');assert(naver?.inquiries===1&&naver.won===1&&naver.monthlyRevenue===350000&&naver.conversionRate===100,'source performance ties attribution to revenue');
  r=await fetch(`${base}/api/tenant/followups`,{headers:{cookie:c1}});j=await json(r);assert(j.followups.length===0,'won lead leaves follow-up queue');

  r=await fetch(`${base}/api/public/leads`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({slug:org1.slug,name:'두번째보호자',phone:'010-2222-3333',grade:'중2',goal:'grade',timing:'month',sourceChannel:'instagram',message:'내신 수학 수업 상담 희망합니다.',privacyConsent:'on'})});j=await json(r);const lostId=j.leadId;
  [r,j]=await patch(base,c1,lostId,{monthlyFee:280000,stage:'phone'});[r,j]=await patch(base,c1,lostId,{stage:'visit'});[r,j]=await patch(base,c1,lostId,{stage:'level_test'});[r,j]=await patch(base,c1,lostId,{stage:'lost',lostReason:'price'});
  assert(j.lead.stage==='lost'&&j.lead.highestStageRank===3&&j.lead.lostReason==='price','lost lead keeps highest stage + reason');
  r=await fetch(`${base}/api/tenant/metrics`,{headers:{cookie:c1}});j=await json(r);assert(j.metrics.funnel.inquiry===2&&j.metrics.funnel.phone===2&&j.metrics.funnel.visit===2&&j.metrics.funnel.levelTest===2&&j.metrics.funnel.trial===1&&j.metrics.funnel.won===1,'lost lead remains in historical funnel');
  assert(j.metrics.lossReasons[0]?.reason==='price'&&j.metrics.lossReasons[0]?.count===1,'loss reason analysis');
  assert(j.metrics.registeredMonthlyRevenue===350000,'lost lead does not inflate actual registered revenue');

  const u2=`owner2-${Date.now()}@example.com`;
  r=await fetch(`${base}/api/auth/signup`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({academyName:'베타영어학원',contactName:'이원장',email:u2,password:'AnotherPass1234',agree:'on'})});j=await json(r);const c2=cookieFrom(r);assert(r.status===201&&j.ok,'second tenant signup');
  r=await fetch(`${base}/api/tenant/leads`,{headers:{cookie:c2}});j=await json(r);assert(r.status===200&&j.leads.length===0,'tenant isolation');

  [r,j]=await patch(base,c1,leadId,{monthlyFee:-1});assert(r.status===400,'negative tuition rejected');
  [r,j]=await patch(base,c1,leadId,{stage:'contacted'});assert(r.status===200&&j.lead.stage==='phone','legacy contacted stage is safely normalized to phone');
  r=await fetch(`${base}/api/billing/start`,{method:'POST',headers:{cookie:c1,'content-type':'application/json'},body:JSON.stringify({plan:'business'})});j=await json(r);assert(r.status===503&&/결제/.test(j.error),'billing fails safely when keys missing');
  r=await fetch(`${base}/api/tenant/leads/${leadId}/analyze`,{method:'POST',headers:{cookie:c2}});assert(r.status===404,'AI analysis respects tenant isolation');
  r=await fetch(`${base}/api/tenant/leads/${leadId}`,{method:'PATCH',headers:{cookie:c1,origin:'https://evil.example','content-type':'application/json'},body:JSON.stringify({stage:'lost'})});assert(r.status===403,'cross-origin state change rejected');

  const adminToken=process.env.ADMIN_TOKEN||'dev-admin-token-change-me';
  r=await fetch(`${base}/api/admin/metrics`,{headers:{authorization:`Bearer ${adminToken}`}});j=await json(r);assert(r.status===200&&j.metrics.organizations===2,'founder metrics');
  r=await fetch(`${base}/api/admin/metrics`);assert(r.status===401,'founder endpoint rejects anonymous');
  r=await fetch(`${base}/api/auth/logout`,{method:'POST',headers:{cookie:c1}});j=await json(r);assert(r.status===200&&j.ok,'logout');
  r=await fetch(`${base}/api/public/leads`,{method:'POST',headers:{'content-type':'application/json'},body:'{"bad":'});assert(r.status===400,'invalid JSON handling');
}catch(e){console.error(e);failures++;}
finally{await new Promise(resolve=>server.close(resolve));await writeFile(storeFile,original);}
if(failures){console.error(`\n${failures} test(s) failed.`);process.exit(1);}console.log('\nAll EnrollFlow 2.3 smoke tests passed.');