import http from 'node:http';
import { readFile, writeFile, mkdir, rename } from 'node:fs/promises';
import { readFileSync, existsSync } from 'node:fs';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const __dirname = fileURLToPath(new URL('.', import.meta.url));

function loadDotEnv() {
  const envFile = join(__dirname, '.env');
  if (!existsSync(envFile)) return;
  const raw = readFileSync(envFile, 'utf8');
  for (const line of raw.split(/\r?\n/)) {
    const s = line.trim();
    if (!s || s.startsWith('#')) continue;
    const i = s.indexOf('=');
    if (i < 1) continue;
    const key = s.slice(0, i).trim();
    let value = s.slice(i + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (!(key in process.env)) process.env[key] = value;
  }
}
loadDotEnv();

const PUBLIC_DIR = join(__dirname, 'public');
const DATA_DIR = join(__dirname, 'data');
const STORE_FILE = join(DATA_DIR, 'store.json');
const PORT = Number(process.env.PORT || 3000);
const NODE_ENV = process.env.NODE_ENV || 'development';
const IS_PROD = NODE_ENV === 'production';
const APP_URL = (process.env.APP_URL || process.env.RENDER_EXTERNAL_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'dev-admin-token-change-me';
const SESSION_SECRET = process.env.SESSION_SECRET || 'dev-session-secret-change-me-please';
const CRON_SECRET = process.env.CRON_SECRET || '';
const SUPABASE_URL = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const SUPABASE_PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || '';
const SUPABASE_SECRET_KEY = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const BILLING_ENCRYPTION_KEY_RAW = process.env.BILLING_ENCRYPTION_KEY || '';
const TOSS_CLIENT_KEY = process.env.TOSS_CLIENT_KEY || '';
const TOSS_SECRET_KEY = process.env.TOSS_SECRET_KEY || '';
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna';
const AI_ENABLED = Boolean(OPENAI_API_KEY);
const USE_SUPABASE = Boolean(SUPABASE_URL && SUPABASE_PUBLISHABLE_KEY && SUPABASE_SECRET_KEY);
const PAYMENT_ENABLED = Boolean(TOSS_CLIENT_KEY && TOSS_SECRET_KEY);
if (IS_PROD) {
  if (!USE_SUPABASE) throw new Error('Production requires SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY and SUPABASE_SECRET_KEY (legacy aliases are also accepted).');
  if (SESSION_SECRET.length < 32 || SESSION_SECRET.startsWith('dev-')) throw new Error('Production requires a strong SESSION_SECRET (32+ chars).');
  if (ADMIN_TOKEN.length < 24 || ADMIN_TOKEN.startsWith('dev-')) throw new Error('Production requires a strong ADMIN_TOKEN (24+ chars).');
  if (!APP_URL.startsWith('https://')) throw new Error('Production APP_URL must use https://');
  if (!parseAesKey(BILLING_ENCRYPTION_KEY_RAW)) throw new Error('Production requires BILLING_ENCRYPTION_KEY as 64 hex chars or base64 for exactly 32 bytes.');
}
function parseAesKey(raw) {
  if (!raw) return null;
  try {
    if (/^[0-9a-f]{64}$/i.test(raw)) return Buffer.from(raw, 'hex');
    const normalized = raw.replace(/-/g, '+').replace(/_/g, '/');
    const buf = Buffer.from(normalized, 'base64');
    if (buf.length === 32) return buf;
    // Render generateValue produces a high-entropy secret string. Derive a stable
    // 32-byte AES key from any sufficiently long generated secret.
    if (String(raw).length >= 32) return crypto.createHash('sha256').update(String(raw)).digest();
    return null;
  } catch { return null; }
}
const BILLING_ENCRYPTION_KEY = parseAesKey(BILLING_ENCRYPTION_KEY_RAW);
function encryptBillingSecret(value) {
  if (!value || String(value).startsWith('enc:v1:')) return value;
  if (!BILLING_ENCRYPTION_KEY) return value;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', BILLING_ENCRYPTION_KEY, iv);
  const ciphertext = Buffer.concat([cipher.update(String(value), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `enc:v1:${iv.toString('base64url')}:${tag.toString('base64url')}:${ciphertext.toString('base64url')}`;
}
function decryptBillingSecret(value) {
  if (!value || !String(value).startsWith('enc:v1:')) return value;
  if (!BILLING_ENCRYPTION_KEY) throw new Error('Encrypted billing key cannot be decrypted because BILLING_ENCRYPTION_KEY is missing.');
  const parts = String(value).split(':');
  if (parts.length !== 5) throw new Error('Encrypted billing key has an invalid format.');
  const iv = Buffer.from(parts[2], 'base64url');
  const tag = Buffer.from(parts[3], 'base64url');
  const ciphertext = Buffer.from(parts[4], 'base64url');
  const decipher = crypto.createDecipheriv('aes-256-gcm', BILLING_ENCRYPTION_KEY, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
}

const MAX_BODY = 64 * 1024;
const rateBuckets = new Map();

const PLAN = Object.freeze({
  starter: { amount: 99000, name: 'Starter', leadLimit: 300, aiDailyLimit: 30 },
  business: { amount: 199000, name: 'Business', leadLimit: 2000, aiDailyLimit: 150 },
  scale: { amount: 299000, name: 'Scale', leadLimit: 1000000, aiDailyLimit: 500 }
});

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp'
};

const ROUTES = new Map([
  ['/', 'index.html'], ['/login', 'login.html'], ['/signup', 'signup.html'], ['/dashboard', 'dashboard.html'],
  ['/apply', 'apply.html'], ['/billing', 'billing.html'], ['/billing-success', 'billing-success.html'],
  ['/billing-fail', 'billing-fail.html'], ['/privacy', 'privacy.html'], ['/terms', 'terms.html'], ['/admin', 'admin.html']
]);

function securityHeaders(contentType = 'text/plain; charset=utf-8') {
  return {
    'Content-Type': contentType,
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Cross-Origin-Opener-Policy': 'same-origin-allow-popups',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' https://js.tosspayments.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self' https://*.tosspayments.com; frame-src https://*.tosspayments.com; base-uri 'self'; form-action 'self'; frame-ancestors 'none'",
    'Cache-Control': 'no-store'
  };
}

function sendJson(res, status, data, extra = {}) {
  const body = JSON.stringify(data);
  res.writeHead(status, { ...securityHeaders('application/json; charset=utf-8'), ...extra, 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}
function sendText(res, status, text) { res.writeHead(status, securityHeaders()); res.end(text); }
function clientIp(req) {
  const f = req.headers['x-forwarded-for'];
  if (typeof f === 'string' && f) return f.split(',')[0].trim();
  return req.socket.remoteAddress || 'unknown';
}
function limited(req, key, limit, windowMs) {
  const now = Date.now(); const id = `${clientIp(req)}:${key}`; const b = rateBuckets.get(id);
  if (!b || now - b.startedAt >= windowMs) { rateBuckets.set(id, { startedAt: now, count: 1 }); return false; }
  b.count += 1; return b.count > limit;
}
async function readBody(req) {
  return await new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', chunk => { size += chunk.length; if (size > MAX_BODY) { reject(Object.assign(new Error('Payload too large'), { status: 413 })); req.destroy(); } else chunks.push(chunk); });
    req.on('end', () => { if (!chunks.length) return resolve({}); try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(Object.assign(new Error('Invalid JSON'), { status: 400 })); } });
    req.on('error', reject);
  });
}
function clean(v, max = 200) { return String(v ?? '').replace(/[<>]/g, '').trim().slice(0, max); }
function validEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
function validPhone(v) { return /^[0-9+()\-\s]{8,20}$/.test(v); }
function uuid() { return crypto.randomUUID(); }
function addDays(date, days) { const d = new Date(date); d.setUTCDate(d.getUTCDate() + days); return d.toISOString(); }
function slugify(value) {
  const base = clean(value, 60).toLowerCase().replace(/[^a-z0-9가-힣]+/g, '-').replace(/^-|-$/g, '').slice(0, 34) || 'academy';
  return `${base}-${crypto.randomBytes(3).toString('hex')}`;
}
function randomCustomerKey() { return `ef_${uuid()}`; }
function planInfo(plan) { return PLAN[plan] || PLAN.business; }
const STAGES = Object.freeze(['new','phone','visit','level_test','trial','won','lost']);
const STAGE_RANK = Object.freeze({ new: 0, contacted: 1, phone: 1, visit: 2, level_test: 3, trial: 4, won: 5, lost: -1 });

function leadScore(body) {
  let s = 30;
  if (body.timing === 'now') s += 30; else if (body.timing === 'month') s += 15;
  if (body.goal === 'exam') s += 20; else if (body.goal === 'grade') s += 15;
  if (body.email) s += 5;
  if ((body.message || '').length >= 20) s += 10;
  return Math.min(100, s);
}

function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
function ruleAnalysis(body, score = leadScore(body)) {
  let priorityScore = score;
  const signals = [];
  const risks = [];
  if (body.timing === 'now') { priorityScore += 8; signals.push('상담 희망 시기가 빠름'); }
  else if (body.timing === 'later') { priorityScore -= 10; risks.push('상담 시기가 구체적이지 않음'); }
  if (body.goal === 'exam') signals.push('시험 대비라는 구체적 목표가 있음');
  if (body.goal === 'grade') signals.push('내신 관리 목표가 명확함');
  if ((body.message || '').trim().length >= 35) signals.push('문의 내용이 비교적 구체적임');
  else risks.push('상담 정보가 짧아 추가 질문이 필요함');
  if (body.sourceChannel && body.sourceChannel !== 'unknown') signals.push('유입 경로가 기록되어 성과 추적 가능');
  priorityScore = clamp(priorityScore, 10, 100);
  const urgency = body.timing === 'now' ? 'high' : body.timing === 'month' ? 'medium' : 'low';
  const riskLevel = priorityScore >= 75 ? 'low' : priorityScore >= 50 ? 'medium' : 'high';
  const goal = body.goal === 'exam' ? '시험 대비' : body.goal === 'grade' ? '내신 관리' : body.goal === 'consult' ? '학습 상담' : '기타 상담';
  const nextAction = urgency === 'high'
    ? '가능하면 오늘 연락해 현재 수준, 희망 시작일, 상담 또는 레벨테스트 가능 시간을 확인하세요.'
    : urgency === 'medium'
      ? '24시간 안에 연락해 구체적인 학습 목표와 방문 상담 가능 시간을 확인하세요.'
      : '관심 과목과 시작 희망 시기를 확인한 뒤 전화 상담 또는 방문 상담 일정을 제안하세요.';
  const suggestedMessage = `안녕하세요, ${clean(body.name, 30)}님. 문의 남겨주셔서 감사합니다. ${goal} 관련해 현재 상황을 간단히 확인한 뒤 가장 적합한 상담 방법을 안내드리고 싶습니다. 통화 가능한 시간을 알려주시면 맞춰 연락드리겠습니다.`;
  return {
    priorityScore,
    urgency,
    riskLevel,
    summary: `${goal} 문의이며, ${body.timing === 'now' ? '빠른 상담 의사가 확인됩니다.' : body.timing === 'month' ? '1개월 내 상담을 희망합니다.' : '상담 시기는 아직 여유가 있습니다.'}`,
    signals: signals.slice(0, 4),
    risks: risks.slice(0, 4),
    nextAction,
    suggestedMessage,
    source: 'rules',
    model: null,
    generatedAt: new Date().toISOString()
  };
}
function sanitizeAnalysis(a, fallback) {
  if (!a || typeof a !== 'object') return fallback;
  const urgency = ['high','medium','low'].includes(a.urgency) ? a.urgency : fallback.urgency;
  const riskLevel = ['low','medium','high'].includes(a.riskLevel) ? a.riskLevel : fallback.riskLevel;
  const arr = v => Array.isArray(v) ? v.map(x => clean(x, 160)).filter(Boolean).slice(0, 4) : [];
  const legacy = Number.isFinite(Number(a.probability)) ? Number(a.probability) : fallback.priorityScore;
  return {
    priorityScore: clamp(Number.isFinite(Number(a.priorityScore)) ? Math.round(Number(a.priorityScore)) : Math.round(legacy), 10, 100),
    urgency,
    riskLevel,
    summary: clean(a.summary || fallback.summary, 320),
    signals: arr(a.signals).length ? arr(a.signals) : fallback.signals,
    risks: arr(a.risks).length ? arr(a.risks) : fallback.risks,
    nextAction: clean(a.nextAction || fallback.nextAction, 420),
    suggestedMessage: clean(a.suggestedMessage || fallback.suggestedMessage, 700),
    source: 'openai',
    model: OPENAI_MODEL,
    generatedAt: new Date().toISOString()
  };
}
function responseText(data) {
  if (typeof data?.output_text === 'string') return data.output_text;
  for (const item of data?.output || []) for (const c of item?.content || []) if (typeof c?.text === 'string') return c.text;
  return '';
}
async function openAIAnalysis(lead) {
  const fallback = ruleAnalysis(lead, lead.score || leadScore(lead));
  if (!AI_ENABLED) return fallback;
  const input = {
    grade: lead.grade || '', goal: lead.goal || '', timing: lead.timing || '', message: lead.message || '',
    sourceChannel: lead.sourceChannel || '', sourceDetail: lead.sourceDetail || '', score: lead.score || 0
  };
  const schema = {
    type: 'object', additionalProperties: false,
    properties: {
      priorityScore: { type: 'integer', minimum: 10, maximum: 100 },
      urgency: { type: 'string', enum: ['high','medium','low'] },
      riskLevel: { type: 'string', enum: ['low','medium','high'] },
      summary: { type: 'string' },
      signals: { type: 'array', items: { type: 'string' }, maxItems: 4 },
      risks: { type: 'array', items: { type: 'string' }, maxItems: 4 },
      nextAction: { type: 'string' },
      suggestedMessage: { type: 'string' }
    },
    required: ['priorityScore','urgency','riskLevel','summary','signals','risks','nextAction','suggestedMessage']
  };
  try {
    const r = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: OPENAI_MODEL,
        input: `당신은 학원 신규등록 상담 운영 보조 도구입니다. 아래 상담 신청 정보만 근거로 "먼저 연락할 순서"를 정하기 위한 운영 우선순위 점수를 10~100 사이로 평가하세요. 이것은 등록 확률이 아니며 등록을 예측하거나 보장하지 않습니다. 민감한 특성, 경제력, 건강, 가족관계 등 제출되지 않은 사실을 추측하지 마세요. 상담자가 보낼 문구는 정중하고 과장 없이 작성하세요.

상담 정보: ${JSON.stringify(input)}`,
        reasoning: { effort: 'low' },
        max_output_tokens: 700,
        text: { format: { type: 'json_schema', name: 'lead_priority_analysis', strict: true, schema } }
      }),
      signal: AbortSignal.timeout(12_000)
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data?.error?.message || `OpenAI ${r.status}`);
    const text = responseText(data); if (!text) throw new Error('OpenAI response text missing');
    return sanitizeAnalysis(JSON.parse(text), fallback);
  } catch (e) {
    console.error('AI analysis fallback:', e.message);
    return fallback;
  }
}
function normalizedStage(stage) { return stage === 'contacted' ? 'phone' : stage; }
function stageRank(lead) {
  const persisted = Number(lead.highestStageRank ?? lead.highest_stage_rank);
  if (Number.isFinite(persisted)) return Math.max(0, persisted);
  return Math.max(0, STAGE_RANK[normalizedStage(lead.stage)] ?? 0);
}
function followUpInfo(lead, now = new Date()) {
  if (['won','lost'].includes(lead.stage)) return null;
  const base = new Date(lead.updatedAt || lead.createdAt || now);
  const stage = normalizedStage(lead.stage);
  const hoursByStage = { new: 0, phone: 48, visit: 24, level_test: 24, trial: 24 };
  const due = new Date(base.getTime() + (hoursByStage[stage] ?? 24) * 60 * 60 * 1000);
  const priorityScore = lead.analysis?.priorityScore ?? lead.score ?? 0;
  const overdue = due <= now;
  return { dueAt: due.toISOString(), overdue, priority: (overdue ? 1000 : 0) + priorityScore };
}
function buildFunnel(leads) {
  const names = ['inquiry','phone','visit','levelTest','trial','won'];
  const counts = names.map((_, rank) => leads.filter(l => stageRank(l) >= rank).length);
  const total = counts[0];
  const pct = n => total ? Math.round(n / total * 1000) / 10 : 0;
  return {
    inquiry: counts[0], phone: counts[1], visit: counts[2], levelTest: counts[3], trial: counts[4], won: counts[5],
    rates: { phone: pct(counts[1]), visit: pct(counts[2]), levelTest: pct(counts[3]), trial: pct(counts[4]), won: pct(counts[5]) }
  };
}
function buildSourcePerformance(leads) {
  const map = new Map();
  for (const l of leads) {
    const key = l.sourceChannel || 'unknown';
    const row = map.get(key) || { source: key, inquiries: 0, won: 0, monthlyRevenue: 0 };
    row.inquiries += 1;
    if (l.stage === 'won') { row.won += 1; row.monthlyRevenue += Math.max(0, Number(l.monthlyFee || 0)); }
    map.set(key, row);
  }
  return [...map.values()].map(r => ({ ...r, conversionRate: r.inquiries ? Math.round(r.won / r.inquiries * 1000) / 10 : 0 }))
    .sort((a,b) => b.monthlyRevenue - a.monthlyRevenue || b.won - a.won || b.inquiries - a.inquiries);
}
function buildLossReasons(leads) {
  const map = new Map();
  for (const l of leads.filter(x => x.stage === 'lost')) {
    const key = l.lostReason || 'unknown';
    map.set(key, (map.get(key) || 0) + 1);
  }
  const total = [...map.values()].reduce((a,b) => a+b, 0);
  return [...map.entries()].map(([reason,count]) => ({ reason, count, share: total ? Math.round(count / total * 1000) / 10 : 0 })).sort((a,b)=>b.count-a.count);
}
function buildRecovery(leads, now = new Date()) {
  const candidates = leads.map(l => ({ lead: l, followUp: followUpInfo(l, now) }))
    .filter(x => x.followUp?.overdue && (x.lead.analysis?.priorityScore ?? x.lead.score ?? 0) >= 60)
    .sort((a,b) => b.followUp.priority - a.followUp.priority);
  const candidateMonthlyRevenue = candidates.reduce((sum, x) => sum + Math.max(0, Number(x.lead.monthlyFee || 0)), 0);
  return { candidateCount: candidates.length, candidateMonthlyRevenue, leadIds: candidates.slice(0, 10).map(x => x.lead.id) };
}

function cookieMap(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) { const i = part.indexOf('='); if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); }
  return out;
}
function cookie(name, value, opts = {}) {
  const items = [`${name}=${encodeURIComponent(value)}`, `Path=${opts.path || '/'}`, 'HttpOnly', 'SameSite=Lax'];
  if (IS_PROD) items.push('Secure');
  if (opts.maxAge !== undefined) items.push(`Max-Age=${Math.max(0, Math.floor(opts.maxAge))}`);
  return items.join('; ');
}
function setSessionCookies(res, accessToken, refreshToken, expiresIn = 3600) {
  const c = [cookie('ef_access', accessToken, { maxAge: expiresIn }), cookie('ef_refresh', refreshToken, { maxAge: 60 * 60 * 24 * 30 })];
  res.setHeader('Set-Cookie', c);
}
function clearSessionCookies(res) { res.setHeader('Set-Cookie', [cookie('ef_access', '', { maxAge: 0 }), cookie('ef_refresh', '', { maxAge: 0 })]); }
function signLocalSession(userId) {
  const payload = Buffer.from(JSON.stringify({ uid: userId, exp: Date.now() + 7 * 24 * 60 * 60 * 1000 })).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}
function verifyLocalSession(token) {
  try {
    const [p, sig] = token.split('.'); if (!p || !sig) return null;
    const expected = crypto.createHmac('sha256', SESSION_SECRET).update(p).digest('base64url');
    if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const data = JSON.parse(Buffer.from(p, 'base64url').toString('utf8')); if (Date.now() > data.exp) return null; return data;
  } catch { return null; }
}
function scrypt(password, salt) { return new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, (e, key) => e ? reject(e) : resolve(key.toString('hex')))); }

async function ensureStore() {
  await mkdir(DATA_DIR, { recursive: true });
  if (!existsSync(STORE_FILE)) await writeFile(STORE_FILE, JSON.stringify({ users: [], organizations: [], memberships: [], leads: [], billingProfiles: [], payments: [], events: [] }, null, 2));
}
function normalizeStore(data) {
  return {
    users: Array.isArray(data.users) ? data.users : [], organizations: Array.isArray(data.organizations) ? data.organizations : [],
    memberships: Array.isArray(data.memberships) ? data.memberships : [], leads: Array.isArray(data.leads) ? data.leads : [],
    billingProfiles: Array.isArray(data.billingProfiles) ? data.billingProfiles : [], payments: Array.isArray(data.payments) ? data.payments : [],
    events: Array.isArray(data.events) ? data.events : []
  };
}
async function loadStore() { await ensureStore(); try { return normalizeStore(JSON.parse(await readFile(STORE_FILE, 'utf8'))); } catch { return normalizeStore({}); } }
let mutationQueue = Promise.resolve();
async function atomicWriteStore(store) { const temp = `${STORE_FILE}.${process.pid}.${uuid()}.tmp`; await writeFile(temp, JSON.stringify(store, null, 2)); await rename(temp, STORE_FILE); }
function mutateStore(mutator) {
  const task = mutationQueue.then(async () => { const s = await loadStore(); const result = await mutator(s); await atomicWriteStore(s); return result; });
  mutationQueue = task.catch(() => {}); return task;
}

async function supabaseRequest(path, { method = 'GET', body, service = false, token, headers = {} } = {}) {
  const key = service ? SUPABASE_SECRET_KEY : SUPABASE_PUBLISHABLE_KEY;
  const requestHeaders = { apikey: key, 'Content-Type': 'application/json', ...headers };
  // New sb_publishable_/sb_secret_ API keys belong in `apikey`, not Bearer Authorization.
  // Authorization is reserved for an authenticated user's JWT.
  if (token) requestHeaders.Authorization = `Bearer ${token}`;
  const r = await fetch(`${SUPABASE_URL}${path}`, {
    method,
    headers: requestHeaders,
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  const text = await r.text(); let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!r.ok) { const e = new Error(data?.msg || data?.message || data?.error_description || data?.error || `Supabase ${r.status}`); e.status = r.status; e.data = data; throw e; }
  return data;
}
async function dbSelect(table, query = '', { service = true, token } = {}) {
  return await supabaseRequest(`/rest/v1/${table}?${query}`, { service, token, headers: { Prefer: 'return=representation' } });
}
async function dbInsert(table, body) {
  return await supabaseRequest(`/rest/v1/${table}`, { method: 'POST', service: true, body, headers: { Prefer: 'return=representation' } });
}
async function dbPatch(table, filter, body) {
  return await supabaseRequest(`/rest/v1/${table}?${filter}`, { method: 'PATCH', service: true, body, headers: { Prefer: 'return=representation' } });
}
async function dbRpc(fn, body) {
  return await supabaseRequest(`/rest/v1/rpc/${fn}`, { method: 'POST', service: true, body });
}
const localAiUsage = new Map();
async function consumeAiQuota(org) {
  const limit = planInfo(org.plan).aiDailyLimit;
  if (!AI_ENABLED) return { allowed: false, limit, used: 0, reason: 'ai_disabled' };
  const day = new Date().toISOString().slice(0, 10);
  if (!USE_SUPABASE) {
    const key = `${org.id}:${day}`; const used = localAiUsage.get(key) || 0;
    if (used >= limit) return { allowed: false, limit, used, reason: 'quota' };
    localAiUsage.set(key, used + 1); return { allowed: true, limit, used: used + 1 };
  }
  const result = await dbRpc('consume_ai_quota', { p_organization_id: org.id, p_limit: limit });
  const row = Array.isArray(result) ? result[0] : result;
  return { allowed: Boolean(row?.allowed), limit, used: Number(row?.used || 0), reason: row?.allowed ? null : 'quota' };
}

async function createOrganizationForUser(userId, academyName, contactName) {
  const createdAt = new Date().toISOString(); const trialEndsAt = addDays(createdAt, 30);
  if (!USE_SUPABASE) {
    return await mutateStore(store => {
      const existing = store.memberships.find(m => m.userId === userId);
      if (existing) return store.organizations.find(o => o.id === existing.organizationId);
      const org = { id: uuid(), ownerId: userId, name: academyName, slug: slugify(academyName), plan: 'business', subscriptionStatus: 'trialing', trialEndsAt, tossCustomerKey: randomCustomerKey(), createdAt, updatedAt: createdAt };
      store.organizations.push(org); store.memberships.push({ userId, organizationId: org.id, role: 'owner', termsVersion: '2026-09-10', privacyVersion: '2026-09-10', termsAcceptedAt: createdAt, privacyAcceptedAt: createdAt, createdAt });
      store.events.push({ id: uuid(), organizationId: org.id, type: 'organization_created', at: createdAt, actorUserId: userId, meta: { contactName } });
      return org;
    });
  }
  const memberships = await dbSelect('memberships', `user_id=eq.${encodeURIComponent(userId)}&select=organization_id&limit=1`);
  if (memberships?.length) return (await dbSelect('organizations', `id=eq.${memberships[0].organization_id}&select=*&limit=1`))[0];
  let org;
  for (let i = 0; i < 3; i++) {
    try {
      [org] = await dbInsert('organizations', { owner_id: userId, name: academyName, slug: slugify(academyName), plan: 'business', subscription_status: 'trialing', trial_ends_at: trialEndsAt, toss_customer_key: randomCustomerKey() });
      break;
    } catch (e) { if (i === 2) throw e; }
  }
  try { await dbInsert('memberships', { user_id: userId, organization_id: org.id, role: 'owner', terms_version: '2026-09-10', privacy_version: '2026-09-10', terms_accepted_at: createdAt, privacy_accepted_at: createdAt }); }
  catch (e) { throw e; }
  return org;
}

async function localUserByEmail(email) { const s = await loadStore(); return s.users.find(u => u.email === email) || null; }
async function getSession(req, res) {
  const cookies = cookieMap(req);
  if (!USE_SUPABASE) {
    const data = verifyLocalSession(cookies.ef_access || ''); if (!data) return null;
    const s = await loadStore(); const user = s.users.find(u => u.id === data.uid); if (!user) return null;
    const membership = s.memberships.find(m => m.userId === user.id); const organization = membership ? s.organizations.find(o => o.id === membership.organizationId) : null;
    return { user: { id: user.id, email: user.email, user_metadata: { contact_name: user.contactName } }, organization, role: membership?.role || null };
  }
  let access = cookies.ef_access || ''; const refresh = cookies.ef_refresh || '';
  async function fetchUser(t) { return await supabaseRequest('/auth/v1/user', { token: t }); }
  let user;
  try { if (access) user = await fetchUser(access); else throw new Error('missing'); }
  catch {
    if (!refresh) return null;
    try {
      const tokenData = await supabaseRequest('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: { refresh_token: refresh } });
      access = tokenData.access_token; setSessionCookies(res, tokenData.access_token, tokenData.refresh_token, tokenData.expires_in); user = tokenData.user || await fetchUser(access);
    } catch { clearSessionCookies(res); return null; }
  }
  const mem = await dbSelect('memberships', `user_id=eq.${encodeURIComponent(user.id)}&select=organization_id,role&limit=1`);
  let organization = null; let role = null;
  if (mem?.length) { role = mem[0].role; organization = (await dbSelect('organizations', `id=eq.${mem[0].organization_id}&select=*&limit=1`))[0] || null; }
  return { user, organization, role, accessToken: access };
}
function publicOrg(org) {
  if (!org) return null;
  return {
    id: org.id, name: org.name, slug: org.slug, plan: org.plan,
    subscriptionStatus: org.subscriptionStatus ?? org.subscription_status,
    trialEndsAt: org.trialEndsAt ?? org.trial_ends_at,
    tossCustomerKey: org.tossCustomerKey ?? org.toss_customer_key
  };
}
async function requireSession(req, res) { const s = await getSession(req, res); if (!s?.user || !s?.organization) { sendJson(res, 401, { ok: false, error: '로그인이 필요합니다.' }); return null; } return s; }

function authAdmin(req) {
  const h = req.headers.authorization || ''; const token = h.startsWith('Bearer ') ? h.slice(7) : req.headers['x-admin-token'];
  if (typeof token !== 'string' || !token) return false;
  const a = crypto.createHash('sha256').update(token).digest(); const b = crypto.createHash('sha256').update(ADMIN_TOKEN).digest(); return crypto.timingSafeEqual(a, b);
}
function sameOrigin(req) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return true;
  if (String(req.headers['sec-fetch-site'] || '').toLowerCase() === 'cross-site') return false;
  const origin = req.headers.origin; if (!origin) return true;
  try { const expected = new URL(APP_URL).origin; const hostOrigin = `${IS_PROD ? 'https' : 'http'}://${req.headers.host}`; return origin === expected || origin === hostOrigin; } catch { return false; }
}

async function listOrgLeads(orgId) {
  if (!USE_SUPABASE) { const s = await loadStore(); return s.leads.filter(l => l.organizationId === orgId).sort((a,b) => Date.parse(b.createdAt)-Date.parse(a.createdAt)); }
  return await dbSelect('leads', `organization_id=eq.${orgId}&select=*&order=created_at.desc`);
}
function shapeLead(l) {
  let analysis = l.analysis ?? l.analysis_json ?? null;
  if (typeof analysis === 'string') { try { analysis = JSON.parse(analysis); } catch { analysis = null; } }
  const stage = normalizedStage(l.stage);
  const shaped = {
    id: l.id, name: l.name, email: l.email, phone: l.phone, grade: l.grade, goal: l.goal, timing: l.timing, message: l.message,
    score: l.score, stage,
    highestStageRank: Number(l.highestStageRank ?? l.highest_stage_rank ?? Math.max(0, STAGE_RANK[stage] ?? 0)),
    sourceChannel: l.sourceChannel ?? l.source_channel ?? 'unknown',
    sourceDetail: l.sourceDetail ?? l.source_detail ?? '',
    monthlyFee: Number(l.monthlyFee ?? l.monthly_fee ?? 0),
    lostReason: l.lostReason ?? l.lost_reason ?? '',
    createdAt: l.createdAt ?? l.created_at, updatedAt: l.updatedAt ?? l.updated_at, analysis
  };
  if (!shaped.analysis) shaped.analysis = ruleAnalysis(shaped, shaped.score);
  else if (shaped.analysis.probability !== undefined && shaped.analysis.priorityScore === undefined) {
    shaped.analysis = { ...shaped.analysis, priorityScore: clamp(Math.round(Number(shaped.analysis.probability) || shaped.score || 50), 10, 100) };
    delete shaped.analysis.probability;
  }
  return shaped;
}
async function getOrgBySlug(slug) {
  if (!USE_SUPABASE) { const s = await loadStore(); return s.organizations.find(o => o.slug === slug) || null; }
  return (await dbSelect('organizations', `slug=eq.${encodeURIComponent(slug)}&select=id,name,slug,plan,subscription_status,trial_ends_at&limit=1`))[0] || null;
}
async function createLead(org, body) {
  const now = new Date().toISOString();
  const sourceChannel = clean(body.sourceChannel || 'unknown', 40) || 'unknown';
  const sourceDetail = clean(body.sourceDetail, 120);
  const score = leadScore(body); const analysis = ruleAnalysis({ ...body, sourceChannel }, score);
  const lead = {
    id: uuid(), organizationId: org.id, name: clean(body.name, 60), email: clean(body.email, 120).toLowerCase(), phone: clean(body.phone, 30),
    grade: clean(body.grade, 40), goal: clean(body.goal, 30), timing: clean(body.timing, 20), message: clean(body.message, 1000),
    score, stage: 'new', highestStageRank: 0, sourceChannel, sourceDetail, monthlyFee: 0, lostReason: '',
    analysis, consentAt: now, createdAt: now, updatedAt: now
  };
  if (!USE_SUPABASE) { await mutateStore(s => { s.leads.unshift(lead); s.events.unshift({ id: uuid(), organizationId: org.id, type: 'lead_created', at: now, meta: { leadId: lead.id, sourceChannel } }); }); return lead; }
  const [row] = await dbInsert('leads', {
    id: lead.id, organization_id: org.id, name: lead.name, email: lead.email || null, phone: lead.phone, grade: lead.grade,
    goal: lead.goal, timing: lead.timing, message: lead.message, score: lead.score, stage: lead.stage, highest_stage_rank: 0,
    source_channel: sourceChannel, source_detail: sourceDetail || null, monthly_fee: 0, lost_reason: null,
    analysis_json: analysis, consent_at: lead.consentAt
  });
  return row;
}
async function saveLeadAnalysis(orgId, leadId, analysis) {
  const now = new Date().toISOString();
  if (!USE_SUPABASE) return await mutateStore(s => { const l = s.leads.find(x => x.id === leadId && x.organizationId === orgId); if (!l) return null; l.analysis = analysis; s.events.unshift({ id: uuid(), organizationId: orgId, type: 'lead_analyzed', at: now, meta: { leadId, source: analysis.source } }); return l; });
  const rows = await dbPatch('leads', `id=eq.${leadId}&organization_id=eq.${orgId}`, { analysis_json: analysis }); return rows?.[0] || null;
}
async function updateLead(orgId, leadId, changes) {
  const now = new Date().toISOString();
  const normalized = {};
  if (changes.stage !== undefined) normalized.stage = normalizedStage(clean(changes.stage, 20));
  if (changes.monthlyFee !== undefined) normalized.monthlyFee = clamp(Math.round(Number(changes.monthlyFee) || 0), 0, 10000000);
  if (changes.lostReason !== undefined) normalized.lostReason = clean(changes.lostReason, 50);
  if (changes.sourceChannel !== undefined) normalized.sourceChannel = clean(changes.sourceChannel || 'unknown', 40) || 'unknown';
  if (changes.sourceDetail !== undefined) normalized.sourceDetail = clean(changes.sourceDetail, 120);
  if (!USE_SUPABASE) return await mutateStore(s => {
    const l = s.leads.find(x => x.id === leadId && x.organizationId === orgId); if (!l) return null;
    if (normalized.stage !== undefined) {
      l.stage = normalized.stage;
      const rank = STAGE_RANK[normalized.stage] ?? 0;
      l.highestStageRank = Math.max(Number(l.highestStageRank || 0), rank);
      if (normalized.stage !== 'lost') l.lostReason = '';
    }
    if (normalized.monthlyFee !== undefined) l.monthlyFee = normalized.monthlyFee;
    if (normalized.lostReason !== undefined) l.lostReason = normalized.lostReason;
    if (normalized.sourceChannel !== undefined) l.sourceChannel = normalized.sourceChannel;
    if (normalized.sourceDetail !== undefined) l.sourceDetail = normalized.sourceDetail;
    l.updatedAt = now;
    s.events.unshift({ id: uuid(), organizationId: orgId, type: 'lead_updated', at: now, meta: { leadId, changes: normalized } });
    return l;
  });
  const existing = (await dbSelect('leads', `id=eq.${leadId}&organization_id=eq.${orgId}&select=stage,highest_stage_rank&limit=1`))[0];
  if (!existing) return null;
  const dbValues = { updated_at: now };
  if (normalized.stage !== undefined) {
    dbValues.stage = normalized.stage;
    dbValues.highest_stage_rank = Math.max(Number(existing.highest_stage_rank || 0), STAGE_RANK[normalized.stage] ?? 0);
    if (normalized.stage !== 'lost' && normalized.lostReason === undefined) dbValues.lost_reason = null;
  }
  if (normalized.monthlyFee !== undefined) dbValues.monthly_fee = normalized.monthlyFee;
  if (normalized.lostReason !== undefined) dbValues.lost_reason = normalized.lostReason || null;
  if (normalized.sourceChannel !== undefined) dbValues.source_channel = normalized.sourceChannel;
  if (normalized.sourceDetail !== undefined) dbValues.source_detail = normalized.sourceDetail || null;
  const rows = await dbPatch('leads', `id=eq.${leadId}&organization_id=eq.${orgId}`, dbValues); return rows?.[0] || null;
}
async function getBillingProfile(orgId) {
  if (!USE_SUPABASE) { const s = await loadStore(); return s.billingProfiles.find(b => b.organizationId === orgId) || null; }
  return (await dbSelect('billing_profiles', `organization_id=eq.${orgId}&select=*&limit=1`))[0] || null;
}
async function saveBillingProfile(orgId, values) {
  const protectedValues = { ...values, billingKey: encryptBillingSecret(values.billingKey) };
  if (!USE_SUPABASE) return await mutateStore(s => { let b = s.billingProfiles.find(x => x.organizationId === orgId); if (!b) { b = { organizationId: orgId, createdAt: new Date().toISOString() }; s.billingProfiles.push(b); } Object.assign(b, protectedValues, { updatedAt: new Date().toISOString() }); return b; });
  const existing = await getBillingProfile(orgId);
  const dbValues = { billing_key: protectedValues.billingKey, customer_key: protectedValues.customerKey, status: protectedValues.status, plan: protectedValues.plan, next_billing_at: protectedValues.nextBillingAt, current_period_end: protectedValues.currentPeriodEnd, updated_at: new Date().toISOString() };
  if (existing) return (await dbPatch('billing_profiles', `organization_id=eq.${orgId}`, dbValues))[0];
  return (await dbInsert('billing_profiles', { organization_id: orgId, ...dbValues }))[0];
}
async function patchOrg(orgId, values) {
  if (!USE_SUPABASE) return await mutateStore(s => { const o = s.organizations.find(x => x.id === orgId); if (!o) return null; Object.assign(o, values, { updatedAt: new Date().toISOString() }); return o; });
  const dbValues = {};
  if ('plan' in values) dbValues.plan = values.plan;
  if ('subscriptionStatus' in values) dbValues.subscription_status = values.subscriptionStatus;
  if ('trialEndsAt' in values) dbValues.trial_ends_at = values.trialEndsAt;
  dbValues.updated_at = new Date().toISOString();
  return (await dbPatch('organizations', `id=eq.${orgId}`, dbValues))[0] || null;
}
async function toss(path, body, idempotencyKey = uuid()) {
  if (!PAYMENT_ENABLED) throw Object.assign(new Error('토스페이먼츠 키가 설정되지 않았습니다.'), { status: 503 });
  const auth = Buffer.from(`${TOSS_SECRET_KEY}:`).toString('base64');
  const r = await fetch(`https://api.tosspayments.com${path}`, { method: 'POST', headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', 'Idempotency-Key': idempotencyKey }, body: JSON.stringify(body), signal: AbortSignal.timeout(65_000) });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(data.message || '결제사 요청에 실패했습니다.'); e.status = 502; e.code = data.code; throw e; }
  return data;
}
async function savePayment(orgId, payment) {
  const row = { id: uuid(), organizationId: orgId, orderId: payment.orderId, paymentKey: payment.paymentKey || null, amount: payment.totalAmount ?? payment.amount, plan: payment.plan, status: payment.status || 'DONE', paidAt: payment.approvedAt || new Date().toISOString(), createdAt: new Date().toISOString() };
  if (!USE_SUPABASE) { await mutateStore(s => { if (!s.payments.some(p => p.orderId === row.orderId)) s.payments.unshift(row); }); return row; }
  try { return (await dbInsert('payments', { id: row.id, organization_id: orgId, order_id: row.orderId, payment_key: row.paymentKey, amount: row.amount, plan: row.plan, status: row.status, paid_at: row.paidAt }))[0]; } catch (e) { if (e.status === 409) return null; throw e; }
}
function billingOrderId(orgId, dueAt) { return `ef_${orgId.replace(/-/g,'').slice(0,12)}_${new Date(dueAt).toISOString().slice(0,10).replace(/-/g,'')}`; }
async function chargeBilling(org, profile) {
  const plan = planInfo(profile.plan || org.plan); const dueAt = profile.nextBillingAt ?? profile.next_billing_at; const billingKey = decryptBillingSecret(profile.billingKey ?? profile.billing_key); const customerKey = profile.customerKey ?? profile.customer_key;
  const orderId = billingOrderId(org.id, dueAt); const idem = crypto.createHash('sha256').update(`${org.id}:${dueAt}`).digest('hex');
  const payment = await toss(`/v1/billing/${encodeURIComponent(billingKey)}`, { customerKey, amount: plan.amount, orderId, orderName: `EF ${plan.name}` }, idem);
  payment.plan = profile.plan || org.plan; await savePayment(org.id, payment);
  const base = new Date(dueAt); const next = new Date(base); next.setUTCMonth(next.getUTCMonth() + 1);
  await saveBillingProfile(org.id, { billingKey, customerKey, status: 'active', plan: profile.plan || org.plan, nextBillingAt: next.toISOString(), currentPeriodEnd: next.toISOString() });
  await patchOrg(org.id, { plan: profile.plan || org.plan, subscriptionStatus: 'active' });
  return payment;
}
async function runDueBilling() {
  if (!PAYMENT_ENABLED) return { charged: 0, failed: 0, skipped: true };
  const now = new Date().toISOString(); let due = [];
  if (!USE_SUPABASE) { const s = await loadStore(); due = s.billingProfiles.filter(b => ['active','past_due'].includes(b.status) && b.nextBillingAt && b.nextBillingAt <= now).map(b => ({ profile: b, org: s.organizations.find(o => o.id === b.organizationId) })).filter(x => x.org); }
  else {
    const rows = await dbSelect('billing_profiles', `status=in.(active,past_due)&next_billing_at=lte.${encodeURIComponent(now)}&select=*`);
    for (const p of rows) { const org = (await dbSelect('organizations', `id=eq.${p.organization_id}&select=*&limit=1`))[0]; if (org) due.push({ profile: p, org }); }
  }
  let charged = 0, failed = 0;
  for (const item of due) {
    try { await chargeBilling(item.org, item.profile); charged++; }
    catch (e) {
      failed++; console.error('Billing charge failed', item.org.id, e.code || e.message);
      // A Toss HTTP error with a documented code is a definite decline/error: move the next retry by one day.
      // Network/timeout errors are ambiguous, so keep the original due time and idempotency key for a safe retry.
      if (e.code) {
        const p = item.profile; const billingKey = p.billingKey ?? p.billing_key; const customerKey = p.customerKey ?? p.customer_key;
        const dueAt = p.nextBillingAt ?? p.next_billing_at; const retryAt = addDays(dueAt || new Date().toISOString(), 1);
        await saveBillingProfile(item.org.id, { billingKey, customerKey, status: 'past_due', plan: p.plan || item.org.plan, nextBillingAt: retryAt, currentPeriodEnd: p.currentPeriodEnd ?? p.current_period_end ?? dueAt });
        await patchOrg(item.org.id, { subscriptionStatus: 'past_due' });
      }
    }
  }
  return { charged, failed, skipped: false };
}

async function api(req, res, url) {
  if (!sameOrigin(req)) return sendJson(res, 403, { ok: false, error: '허용되지 않은 요청 출처입니다.' });

  if (url.pathname === '/api/health' && req.method === 'GET') return sendJson(res, 200, { ok: true, service: 'EnrollFlow', version: '2.3.0', mode: USE_SUPABASE ? 'supabase' : 'local', paymentEnabled: PAYMENT_ENABLED, aiEnabled: AI_ENABLED, aiModel: AI_ENABLED ? OPENAI_MODEL : null, time: new Date().toISOString() });
  if (url.pathname === '/api/ready' && req.method === 'GET') {
    if (!USE_SUPABASE) return sendJson(res, 200, { ok: true, mode: 'local', database: 'local-fallback' });
    try { await dbSelect('organizations', 'select=id&limit=1'); return sendJson(res, 200, { ok: true, mode: 'supabase', database: 'reachable' }); }
    catch (e) { return sendJson(res, 503, { ok: false, mode: 'supabase', database: 'unreachable' }); }
  }
  if (url.pathname === '/api/config' && req.method === 'GET') return sendJson(res, 200, { ok: true, mode: USE_SUPABASE ? 'supabase' : 'local', paymentEnabled: PAYMENT_ENABLED, aiEnabled: AI_ENABLED, aiModel: AI_ENABLED ? OPENAI_MODEL : null, tossClientKey: PAYMENT_ENABLED ? TOSS_CLIENT_KEY : null, plans: PLAN });

  if (url.pathname === '/api/auth/signup' && req.method === 'POST') {
    if (limited(req, 'signup', 6, 30 * 60_000)) return sendJson(res, 429, { ok: false, error: '가입 시도가 너무 많습니다. 잠시 후 다시 시도해 주세요.' });
    const b = await readBody(req); const email = clean(b.email, 120).toLowerCase(); const password = String(b.password || ''); const contactName = clean(b.contactName, 50); const academyName = clean(b.academyName, 80);
    if (!validEmail(email) || contactName.length < 2 || academyName.length < 2) return sendJson(res, 400, { ok: false, error: '이메일, 담당자명, 학원명을 확인해 주세요.' });
    if (!(b.agree === true || b.agree === 'on')) return sendJson(res, 400, { ok: false, error: '이용약관과 개인정보처리방침 동의가 필요합니다.' });
    if (password.length < 10 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) return sendJson(res, 400, { ok: false, error: '비밀번호는 영문과 숫자를 포함해 10자 이상이어야 합니다.' });
    if (!USE_SUPABASE) {
      if (await localUserByEmail(email)) return sendJson(res, 409, { ok: false, error: '이미 가입된 이메일입니다.' });
      const salt = crypto.randomBytes(16).toString('hex'); const passwordHash = await scrypt(password, salt); const user = { id: uuid(), email, passwordHash, salt, contactName, createdAt: new Date().toISOString() };
      await mutateStore(s => { s.users.push(user); }); const org = await createOrganizationForUser(user.id, academyName, contactName);
      const token = signLocalSession(user.id); res.setHeader('Set-Cookie', cookie('ef_access', token, { maxAge: 7 * 24 * 60 * 60 }));
      return sendJson(res, 201, { ok: true, emailConfirmationRequired: false, organization: publicOrg(org) });
    }
    try {
      const auth = await supabaseRequest('/auth/v1/signup', { method: 'POST', body: { email, password, data: { contact_name: contactName } } });
      const user = auth.user; if (!user?.id) throw new Error('회원 생성 결과를 확인할 수 없습니다.');
      const org = await createOrganizationForUser(user.id, academyName, contactName);
      if (auth.access_token && auth.refresh_token) setSessionCookies(res, auth.access_token, auth.refresh_token, auth.expires_in || 3600);
      return sendJson(res, 201, { ok: true, emailConfirmationRequired: !auth.access_token, organization: publicOrg(org) });
    } catch (e) { return sendJson(res, e.status === 422 || e.status === 400 ? 400 : 502, { ok: false, error: e.message }); }
  }

  if (url.pathname === '/api/auth/login' && req.method === 'POST') {
    if (limited(req, 'login', 12, 15 * 60_000)) return sendJson(res, 429, { ok: false, error: '로그인 시도가 너무 많습니다. 잠시 후 다시 시도해 주세요.' });
    const b = await readBody(req); const email = clean(b.email, 120).toLowerCase(); const password = String(b.password || '');
    if (!validEmail(email) || !password) return sendJson(res, 400, { ok: false, error: '이메일과 비밀번호를 입력해 주세요.' });
    if (!USE_SUPABASE) {
      const u = await localUserByEmail(email); if (!u) return sendJson(res, 401, { ok: false, error: '이메일 또는 비밀번호가 올바르지 않습니다.' });
      const hash = await scrypt(password, u.salt); const ok = hash.length === u.passwordHash.length && crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(u.passwordHash));
      if (!ok) return sendJson(res, 401, { ok: false, error: '이메일 또는 비밀번호가 올바르지 않습니다.' });
      res.setHeader('Set-Cookie', cookie('ef_access', signLocalSession(u.id), { maxAge: 7 * 24 * 60 * 60 })); return sendJson(res, 200, { ok: true });
    }
    try { const auth = await supabaseRequest('/auth/v1/token?grant_type=password', { method: 'POST', body: { email, password } }); setSessionCookies(res, auth.access_token, auth.refresh_token, auth.expires_in || 3600); return sendJson(res, 200, { ok: true }); }
    catch { return sendJson(res, 401, { ok: false, error: '이메일 또는 비밀번호가 올바르지 않거나 이메일 인증이 필요합니다.' }); }
  }

  if (url.pathname === '/api/auth/logout' && req.method === 'POST') { clearSessionCookies(res); return sendJson(res, 200, { ok: true }); }
  if (url.pathname === '/api/me' && req.method === 'GET') {
    const s = await getSession(req, res); if (!s?.user || !s.organization) return sendJson(res, 401, { ok: false, error: '로그인이 필요합니다.' });
    const bp = await getBillingProfile(s.organization.id);
    return sendJson(res, 200, { ok: true, user: { id: s.user.id, email: s.user.email, contactName: s.user.user_metadata?.contact_name || '' }, organization: publicOrg(s.organization), role: s.role, billing: bp ? { status: bp.status, plan: bp.plan, nextBillingAt: bp.nextBillingAt ?? bp.next_billing_at } : null });
  }

  if (url.pathname === '/api/public/academy' && req.method === 'GET') {
    const slug = clean(url.searchParams.get('slug'), 80); if (!slug) return sendJson(res, 400, { ok: false, error: '학원 링크가 올바르지 않습니다.' });
    const org = await getOrgBySlug(slug); if (!org) return sendJson(res, 404, { ok: false, error: '학원을 찾을 수 없습니다.' });
    return sendJson(res, 200, { ok: true, academy: { name: org.name, slug: org.slug } });
  }
  if (url.pathname === '/api/public/leads' && req.method === 'POST') {
    if (limited(req, 'public-lead', 8, 10 * 60_000)) return sendJson(res, 429, { ok: false, error: '요청이 너무 많습니다. 잠시 후 다시 시도해 주세요.' });
    const b = await readBody(req); if (b.website) return sendJson(res, 200, { ok: true });
    const slug = clean(b.slug, 80); const name = clean(b.name, 60); const phone = clean(b.phone, 30); const email = clean(b.email, 120).toLowerCase();
    if (!slug || name.length < 2 || !validPhone(phone)) return sendJson(res, 400, { ok: false, error: '이름과 전화번호를 확인해 주세요.' });
    if (!(b.privacyConsent === true || b.privacyConsent === 'on')) return sendJson(res, 400, { ok: false, error: '상담을 위한 개인정보 수집·이용 동의가 필요합니다.' });
    if (email && !validEmail(email)) return sendJson(res, 400, { ok: false, error: '이메일 형식을 확인해 주세요.' });
    const org = await getOrgBySlug(slug); if (!org) return sendJson(res, 404, { ok: false, error: '학원을 찾을 수 없습니다.' });
    const lead = await createLead(org, { ...b, name, phone, email }); return sendJson(res, 201, { ok: true, leadId: lead.id });
  }

  if (url.pathname === '/api/tenant/leads' && req.method === 'GET') {
    const s = await requireSession(req, res); if (!s) return; const leads = await listOrgLeads(s.organization.id); return sendJson(res, 200, { ok: true, leads: leads.map(shapeLead) });
  }
  if (url.pathname === '/api/tenant/metrics' && req.method === 'GET') {
    const s = await requireSession(req, res); if (!s) return;
    const leads = (await listOrgLeads(s.organization.id)).map(shapeLead);
    const won = leads.filter(l => l.stage === 'won').length;
    const funnel = buildFunnel(leads);
    const sourcePerformance = buildSourcePerformance(leads);
    const lossReasons = buildLossReasons(leads);
    const recovery = buildRecovery(leads);
    const registeredMonthlyRevenue = leads.filter(l => l.stage === 'won').reduce((sum,l)=>sum+Math.max(0,Number(l.monthlyFee||0)),0);
    return sendJson(res, 200, { ok: true, metrics: {
      total: leads.length, new: leads.filter(l => l.stage === 'new').length, won,
      conversionRate: leads.length ? Math.round(won / leads.length * 1000) / 10 : 0,
      avgPriorityScore: leads.length ? Math.round(leads.reduce((a,l)=>a+(l.analysis?.priorityScore || l.score || 0),0)/leads.length) : 0,
      registeredMonthlyRevenue, funnel, sourcePerformance, lossReasons, recovery
    } });
  }
  if (url.pathname === '/api/tenant/followups' && req.method === 'GET') {
    const s = await requireSession(req, res); if (!s) return; const leads = (await listOrgLeads(s.organization.id)).map(shapeLead); const now = new Date();
    const followups = leads.map(l => ({ lead: l, info: followUpInfo(l, now) })).filter(x => x.info).sort((a,b) => b.info.priority - a.info.priority || Date.parse(a.info.dueAt) - Date.parse(b.info.dueAt)).slice(0, 12).map(x => ({ ...x.lead, followUp: x.info }));
    return sendJson(res, 200, { ok: true, dueCount: followups.filter(x => x.followUp.overdue).length, followups });
  }
  const analyzeMatch = url.pathname.match(/^\/api\/tenant\/leads\/([0-9a-f-]{36})\/analyze$/i);
  if (analyzeMatch && req.method === 'POST') {
    const s = await requireSession(req, res); if (!s) return; if (limited(req, `analyze-${s.organization.id}`, 30, 60 * 60_000)) return sendJson(res, 429, { ok: false, error: 'AI 분석 요청이 너무 많습니다. 잠시 후 다시 시도해 주세요.' });
    const leads = (await listOrgLeads(s.organization.id)).map(shapeLead); const lead = leads.find(l => l.id === analyzeMatch[1]); if (!lead) return sendJson(res, 404, { ok: false, error: '리드를 찾을 수 없습니다.' });
    let quota = { allowed: false, reason: 'ai_disabled', limit: planInfo(s.organization.plan).aiDailyLimit, used: 0 };
    if (AI_ENABLED) quota = await consumeAiQuota(s.organization);
    const analysis = quota.allowed ? await openAIAnalysis(lead) : ruleAnalysis(lead, lead.score || leadScore(lead));
    const saved = await saveLeadAnalysis(s.organization.id, lead.id, analysis); if (!saved) return sendJson(res, 404, { ok: false, error: '리드를 찾을 수 없습니다.' });
    return sendJson(res, 200, { ok: true, analysis, aiEnabled: AI_ENABLED, quota });
  }
  const leadMatch = url.pathname.match(/^\/api\/tenant\/leads\/([0-9a-f-]{36})$/i);
  if (leadMatch && req.method === 'PATCH') {
    const s = await requireSession(req, res); if (!s) return;
    const b = await readBody(req);
    if (b.stage !== undefined && !STAGES.includes(normalizedStage(clean(b.stage, 20)))) return sendJson(res, 400, { ok: false, error: '잘못된 단계입니다.' });
    if (b.monthlyFee !== undefined && (!Number.isFinite(Number(b.monthlyFee)) || Number(b.monthlyFee) < 0 || Number(b.monthlyFee) > 10000000)) return sendJson(res, 400, { ok: false, error: '월 수강료를 확인해 주세요.' });
    if (normalizedStage(b.stage) === 'lost' && b.lostReason !== undefined && !clean(b.lostReason, 50)) return sendJson(res, 400, { ok: false, error: '이탈 사유를 확인해 주세요.' });
    const lead = await updateLead(s.organization.id, leadMatch[1], {
      stage: b.stage, monthlyFee: b.monthlyFee, lostReason: b.lostReason, sourceChannel: b.sourceChannel, sourceDetail: b.sourceDetail
    });
    if (!lead) return sendJson(res, 404, { ok: false, error: '리드를 찾을 수 없습니다.' });
    return sendJson(res, 200, { ok: true, lead: shapeLead(lead) });
  }

  if (url.pathname === '/api/billing/start' && req.method === 'POST') {
    const s = await requireSession(req, res); if (!s) return; const b = await readBody(req); const plan = ['starter','business','scale'].includes(b.plan) ? b.plan : 'business'; const org = publicOrg(s.organization);
    if (!PAYMENT_ENABLED) return sendJson(res, 503, { ok: false, error: '결제 테스트 키가 아직 설정되지 않았습니다. .env의 TOSS_CLIENT_KEY/TOSS_SECRET_KEY를 설정해 주세요.' });
    return sendJson(res, 200, { ok: true, clientKey: TOSS_CLIENT_KEY, customerKey: org.tossCustomerKey, plan, amount: planInfo(plan).amount, customerName: s.user.user_metadata?.contact_name || org.name, customerEmail: s.user.email, successUrl: `${APP_URL}/billing-success?plan=${plan}`, failUrl: `${APP_URL}/billing-fail?plan=${plan}` });
  }
  if (url.pathname === '/api/billing/issue' && req.method === 'POST') {
    const s = await requireSession(req, res); if (!s) return; const b = await readBody(req); const authKey = clean(b.authKey, 300); const customerKey = clean(b.customerKey, 80); const plan = ['starter','business','scale'].includes(b.plan) ? b.plan : null; const org = publicOrg(s.organization);
    if (!authKey || !plan || customerKey !== org.tossCustomerKey) return sendJson(res, 400, { ok: false, error: '자동결제 인증 정보가 올바르지 않습니다.' });
    try {
      const billing = await toss('/v1/billing/authorizations/issue', { authKey, customerKey }, crypto.createHash('sha256').update(`${org.id}:${authKey}`).digest('hex'));
      const nextBillingAt = new Date(org.trialEndsAt) > new Date() ? org.trialEndsAt : new Date().toISOString();
      await saveBillingProfile(org.id, { billingKey: billing.billingKey, customerKey, status: 'active', plan, nextBillingAt, currentPeriodEnd: nextBillingAt });
      await patchOrg(org.id, { plan, subscriptionStatus: new Date(nextBillingAt) > new Date() ? 'trialing' : 'active' });
      return sendJson(res, 200, { ok: true, plan, nextBillingAt });
    } catch (e) { return sendJson(res, e.status || 502, { ok: false, error: e.message, code: e.code || null }); }
  }
  if (url.pathname === '/api/billing/cancel' && req.method === 'POST') {
    const s = await requireSession(req, res); if (!s) return; const p = await getBillingProfile(s.organization.id); if (!p) return sendJson(res, 404, { ok: false, error: '등록된 결제수단이 없습니다.' });
    await saveBillingProfile(s.organization.id, { billingKey: p.billingKey ?? p.billing_key, customerKey: p.customerKey ?? p.customer_key, status: 'canceled', plan: p.plan || s.organization.plan, nextBillingAt: p.nextBillingAt ?? p.next_billing_at, currentPeriodEnd: p.currentPeriodEnd ?? p.current_period_end });
    await patchOrg(s.organization.id, { subscriptionStatus: 'canceled' }); return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === '/api/cron/billing' && ['GET','POST'].includes(req.method)) {
    const h = req.headers.authorization || ''; const token = h.startsWith('Bearer ') ? h.slice(7) : req.headers['x-cron-secret'];
    if (!CRON_SECRET || token !== CRON_SECRET) return sendJson(res, 401, { ok: false, error: 'cron 인증이 필요합니다.' });
    const result = await runDueBilling(); return sendJson(res, 200, { ok: true, ...result });
  }

  if (url.pathname === '/api/admin/metrics' && req.method === 'GET') {
    if (!authAdmin(req)) return sendJson(res, 401, { ok: false, error: '관리자 인증이 필요합니다.' });
    let orgs, payments;
    if (!USE_SUPABASE) { const s = await loadStore(); orgs = s.organizations; payments = s.payments; }
    else { orgs = await dbSelect('organizations', 'select=*'); payments = await dbSelect('payments', 'select=*'); }
    const active = orgs.filter(o => ['active','trialing'].includes(o.subscriptionStatus ?? o.subscription_status)); const mrr = active.filter(o => (o.subscriptionStatus ?? o.subscription_status) === 'active').reduce((a,o)=>a+planInfo(o.plan).amount,0);
    return sendJson(res, 200, { ok: true, metrics: { organizations: orgs.length, trials: active.filter(o => (o.subscriptionStatus ?? o.subscription_status) === 'trialing').length, active: active.filter(o => (o.subscriptionStatus ?? o.subscription_status) === 'active').length, mrr, payments: payments.length } });
  }
  if (url.pathname === '/api/admin/organizations' && req.method === 'GET') {
    if (!authAdmin(req)) return sendJson(res, 401, { ok: false, error: '관리자 인증이 필요합니다.' }); let orgs;
    if (!USE_SUPABASE) orgs = (await loadStore()).organizations; else orgs = await dbSelect('organizations', 'select=*&order=created_at.desc');
    return sendJson(res, 200, { ok: true, organizations: orgs.map(publicOrg) });
  }

  return false;
}

async function serveStatic(req, res, url) {
  let pathname = decodeURIComponent(url.pathname); if (ROUTES.has(pathname)) pathname = `/${ROUTES.get(pathname)}`;
  const safe = normalize(pathname).replace(/^(\.\.[/\\])+/, ''); const full = join(PUBLIC_DIR, safe);
  if (!full.startsWith(PUBLIC_DIR)) return sendText(res, 403, 'Forbidden');
  try {
    const content = await readFile(full); const type = MIME[extname(full).toLowerCase()] || 'application/octet-stream'; const headers = securityHeaders(type);
    if (['.css','.js','.svg','.png','.jpg','.jpeg','.webp'].includes(extname(full).toLowerCase())) headers['Cache-Control'] = 'public, max-age=3600';
    res.writeHead(200, { ...headers, 'Content-Length': content.length }); res.end(content);
  } catch { sendText(res, 404, 'Not Found'); }
}

export const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    if (url.pathname.startsWith('/api/')) { const handled = await api(req, res, url); if (handled !== false) return; return sendJson(res, 404, { ok: false, error: 'API endpoint not found' }); }
    await serveStatic(req, res, url);
  } catch (e) { if (!e.status || e.status >= 500) console.error(e); if (!res.headersSent) sendJson(res, e.status || 500, { ok: false, error: e.status ? e.message : '서버 오류가 발생했습니다.' }); else res.end(); }
});

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`EnrollFlow 2.3 running at http://localhost:${PORT}`);
    console.log(`Data mode: ${USE_SUPABASE ? 'Supabase' : 'local development fallback'}`);
    console.log(`Payments: ${PAYMENT_ENABLED ? 'configured' : 'disabled'}`);
    console.log(`AI analysis: ${AI_ENABLED ? OPENAI_MODEL : 'rules fallback (OPENAI_API_KEY not set)'}`);
    if (IS_PROD && (!USE_SUPABASE || SESSION_SECRET.startsWith('dev-') || ADMIN_TOKEN.startsWith('dev-'))) console.warn('WARNING: production secrets/database are not fully configured.');
  });
  const shutdown = signal => { console.log(`${signal} received; closing HTTP server.`); server.close(() => process.exit(0)); setTimeout(() => process.exit(1), 10_000).unref(); };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}
