create extension if not exists pgcrypto;

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  slug text not null unique,
  plan text not null default 'business' check (plan in ('starter','business','scale')),
  subscription_status text not null default 'trialing' check (subscription_status in ('trialing','active','past_due','canceled')),
  trial_ends_at timestamptz not null default (now() + interval '30 days'),
  toss_customer_key text not null unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.memberships (
  user_id uuid not null references auth.users(id) on delete cascade,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  role text not null default 'owner' check (role in ('owner','admin','staff')),
  terms_version text not null,
  privacy_version text not null,
  terms_accepted_at timestamptz not null,
  privacy_accepted_at timestamptz not null,
  created_at timestamptz not null default now(),
  primary key (user_id, organization_id)
);

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  email text,
  phone text not null,
  grade text,
  goal text,
  timing text,
  message text,
  score integer not null default 30 check (score between 0 and 100),
  stage text not null default 'new' check (stage in ('new','contacted','trial','won','lost')),
  consent_at timestamptz not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists leads_org_created_idx on public.leads(organization_id, created_at desc);
create index if not exists leads_org_stage_idx on public.leads(organization_id, stage);

create table if not exists public.billing_profiles (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  billing_key text not null,
  customer_key text not null,
  plan text not null check (plan in ('starter','business','scale')),
  status text not null default 'active' check (status in ('active','canceled','past_due')),
  next_billing_at timestamptz,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists billing_due_idx on public.billing_profiles(status, next_billing_at);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  order_id text not null unique,
  payment_key text,
  amount integer not null check (amount >= 0),
  plan text not null check (plan in ('starter','business','scale')),
  status text not null,
  paid_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists payments_org_created_idx on public.payments(organization_id, created_at desc);

alter table public.organizations enable row level security;
alter table public.memberships enable row level security;
alter table public.leads enable row level security;
alter table public.billing_profiles enable row level security;
alter table public.payments enable row level security;

revoke all on public.organizations, public.memberships, public.leads, public.billing_profiles, public.payments from anon, authenticated;
grant select, update on public.organizations to authenticated;
grant select on public.memberships to authenticated;
grant select, insert, update on public.leads to authenticated;

create policy "members read organization" on public.organizations for select to authenticated
using (exists (select 1 from public.memberships m where m.organization_id = organizations.id and m.user_id = (select auth.uid())));

create policy "owners update organization" on public.organizations for update to authenticated
using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()));

create policy "users read own memberships" on public.memberships for select to authenticated
using (user_id = (select auth.uid()));

create policy "members read leads" on public.leads for select to authenticated
using (exists (select 1 from public.memberships m where m.organization_id = leads.organization_id and m.user_id = (select auth.uid())));

create policy "members insert leads" on public.leads for insert to authenticated
with check (exists (select 1 from public.memberships m where m.organization_id = leads.organization_id and m.user_id = (select auth.uid())));

create policy "members update leads" on public.leads for update to authenticated
using (exists (select 1 from public.memberships m where m.organization_id = leads.organization_id and m.user_id = (select auth.uid())))
with check (exists (select 1 from public.memberships m where m.organization_id = leads.organization_id and m.user_id = (select auth.uid())));

-- billing_profiles/payments intentionally have no anon/authenticated grants or policies.
-- Only the server-side service role may access billing keys and payment records.
