-- EnrollFlow 2.1: AI conversion analysis metadata.
-- Safe to run after 001_enrollflow.sql.
alter table public.leads
  add column if not exists analysis_json jsonb;

comment on column public.leads.analysis_json is 'Operational lead analysis. Contains an estimated conversion probability, rationale, follow-up recommendation and generated-at metadata.';
