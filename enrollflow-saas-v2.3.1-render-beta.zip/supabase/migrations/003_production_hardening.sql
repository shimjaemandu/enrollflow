-- EnrollFlow 2.2 production hardening
-- 1) Atomic per-tenant/day OpenAI quota accounting
-- 2) updated_at automation

create table if not exists public.ai_usage_daily (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  usage_day date not null default current_date,
  used integer not null default 0 check (used >= 0),
  updated_at timestamptz not null default now(),
  primary key (organization_id, usage_day)
);

alter table public.ai_usage_daily enable row level security;
revoke all on public.ai_usage_daily from anon, authenticated;

create or replace function public.consume_ai_quota(p_organization_id uuid, p_limit integer)
returns table(allowed boolean, used integer)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_used integer;
begin
  if p_limit < 1 then return query select false, 0; return; end if;
  insert into public.ai_usage_daily(organization_id, usage_day, used, updated_at)
  values (p_organization_id, current_date, 1, now())
  on conflict (organization_id, usage_day) do update
    set used = public.ai_usage_daily.used + 1, updated_at = now()
    where public.ai_usage_daily.used < p_limit
  returning ai_usage_daily.used into v_used;
  if v_used is null then
    select a.used into v_used from public.ai_usage_daily a
      where a.organization_id = p_organization_id and a.usage_day = current_date;
    return query select false, coalesce(v_used, 0);
  end if;
  return query select true, v_used;
end;
$$;
revoke all on function public.consume_ai_quota(uuid, integer) from public, anon, authenticated;
grant execute on function public.consume_ai_quota(uuid, integer) to service_role;

create or replace function public.set_updated_at()
returns trigger language plpgsql
set search_path = public
as $$ begin new.updated_at = now(); return new; end $$;

drop trigger if exists organizations_set_updated_at on public.organizations;
create trigger organizations_set_updated_at before update on public.organizations for each row execute function public.set_updated_at();
drop trigger if exists leads_set_updated_at on public.leads;
create trigger leads_set_updated_at before update on public.leads for each row execute function public.set_updated_at();
drop trigger if exists billing_profiles_set_updated_at on public.billing_profiles;
create trigger billing_profiles_set_updated_at before update on public.billing_profiles for each row execute function public.set_updated_at();
