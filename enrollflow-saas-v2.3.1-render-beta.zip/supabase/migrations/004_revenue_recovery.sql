-- EnrollFlow 2.3: academy-specific acquisition attribution, loss analysis and six-stage funnel.
-- Safe to run after 001, 002, 003.

alter table public.leads drop constraint if exists leads_stage_check;

update public.leads set stage = 'phone' where stage = 'contacted';

alter table public.leads
  add column if not exists source_channel text not null default 'unknown',
  add column if not exists source_detail text,
  add column if not exists monthly_fee integer not null default 0 check (monthly_fee between 0 and 10000000),
  add column if not exists lost_reason text,
  add column if not exists highest_stage_rank integer not null default 0 check (highest_stage_rank between 0 and 5);

update public.leads
set highest_stage_rank = case stage
  when 'new' then greatest(highest_stage_rank, 0)
  when 'phone' then greatest(highest_stage_rank, 1)
  when 'visit' then greatest(highest_stage_rank, 2)
  when 'level_test' then greatest(highest_stage_rank, 3)
  when 'trial' then greatest(highest_stage_rank, 4)
  when 'won' then greatest(highest_stage_rank, 5)
  else highest_stage_rank
end;

alter table public.leads
  add constraint leads_stage_check check (stage in ('new','phone','visit','level_test','trial','won','lost'));

create index if not exists leads_org_source_idx on public.leads(organization_id, source_channel);
create index if not exists leads_org_lost_reason_idx on public.leads(organization_id, lost_reason) where stage = 'lost';

create or replace function public.set_lead_stage_rank()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  v_rank integer;
  v_old_rank integer := 0;
begin
  if tg_op <> 'INSERT' then v_old_rank := coalesce(old.highest_stage_rank, 0); end if;
  v_rank := case new.stage
    when 'new' then 0
    when 'phone' then 1
    when 'visit' then 2
    when 'level_test' then 3
    when 'trial' then 4
    when 'won' then 5
    else greatest(v_old_rank, coalesce(new.highest_stage_rank, 0))
  end;
  new.highest_stage_rank := greatest(v_old_rank, coalesce(new.highest_stage_rank, 0), v_rank);
  if new.stage <> 'lost' then new.lost_reason := null; end if;
  return new;
end;
$$;

revoke all on function public.set_lead_stage_rank() from public, anon, authenticated;

drop trigger if exists leads_stage_rank_guard on public.leads;
create trigger leads_stage_rank_guard
before insert or update of stage, highest_stage_rank, lost_reason on public.leads
for each row execute function public.set_lead_stage_rank();

comment on column public.leads.highest_stage_rank is 'Highest academy conversion stage reached: 0 inquiry, 1 phone, 2 visit, 3 level test, 4 trial, 5 enrolled.';
comment on column public.leads.monthly_fee is 'Monthly tuition amount assigned by academy staff; used for actual registered monthly revenue and recovery-candidate totals.';
comment on column public.leads.source_channel is 'Acquisition channel selected on inquiry or corrected by academy staff.';
comment on column public.leads.lost_reason is 'Reason recorded when the lead is marked lost.';

comment on column public.leads.analysis_json is 'Operational lead analysis with a non-probabilistic priorityScore, rationale, follow-up recommendation and generated-at metadata.';
